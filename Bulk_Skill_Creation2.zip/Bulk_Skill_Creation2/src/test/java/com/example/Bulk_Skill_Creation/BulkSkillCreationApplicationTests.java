package com.example.Bulk_Skill_Creation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulkSkillCreationApplicationTests {

	@Test
	void contextLoads() {
	}

}
