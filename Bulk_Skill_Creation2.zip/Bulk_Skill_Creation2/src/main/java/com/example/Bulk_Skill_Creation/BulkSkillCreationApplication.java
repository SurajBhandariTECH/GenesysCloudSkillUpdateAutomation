package com.example.Bulk_Skill_Creation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BulkSkillCreationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BulkSkillCreationApplication.class, args);
	}

}
