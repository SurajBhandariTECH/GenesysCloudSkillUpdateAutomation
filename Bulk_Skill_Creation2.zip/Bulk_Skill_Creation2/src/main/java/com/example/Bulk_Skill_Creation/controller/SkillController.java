package com.example.Bulk_Skill_Creation.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.Bulk_Skill_Creation.service.GenesysServices;
import com.example.Bulk_Skill_Creation.service.OrgConfigService;
import com.mypurecloud.sdk.v2.ApiClient;
import com.mypurecloud.sdk.v2.Configuration;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/skills")
public class SkillController {
	
	@Autowired
	private OrgConfigService orgConfigService;
	
	@Autowired
	private GenesysServices genesysService;
	
	public SkillController(GenesysServices genesysService) {
		this.genesysService = genesysService;
	}
	
	
	// Show login form
	@GetMapping("/login")
	public String showLoginForm(Model model) {
		model.addAttribute("environment",List.of("mypurecloud.com","usw2.pure.cloud","eu.pure.cloud"));
		return "login";
	}
	
	// Handle login
	
	@PostMapping("/login")
	public String connectTogenesys(
			@RequestParam("organizationName")String organizationName,
			@RequestParam("environment")String environment,
			RedirectAttributes redirectAttributes,
			HttpSession session,
			Model model) {
		
		try {
			
			Map<String, String> credentials = orgConfigService.getCredentials(organizationName);
			String clientId = credentials.get("clientId");
			String clientSecret = credentials.get("clientSecret");
			
			if(clientId==null || clientSecret==null || clientId=="" ||clientSecret=="") {
				throw new IllegalArgumentException("Error: Client Credentials not found for organization "+ organizationName);
				
			}
			
			
				//initialize the Genesys API Client
			ApiClient apiClient = ApiClient.Builder.standard().withBasePath("https://api."+environment).build();
			apiClient.authorizeClientCredentials(clientId, clientSecret);
			Configuration.setDefaultApiClient(apiClient);
//			System.out.println("clientId"+clientId+" client Secret"+clientSecret);
			
			//Store credentials in the session
			session.setAttribute("organizationName", organizationName);
			session.setAttribute("environment", environment);
			session.setAttribute("credentials", credentials);
			
		
		//save organization and environment in session or attributes for next page
		redirectAttributes.addFlashAttribute("organizationName",organizationName);
		redirectAttributes.addFlashAttribute("environment",environment);
		return "redirect:/skills/upload";
		
	}catch(IllegalArgumentException e) {
		model.addAttribute("errorMessage",e.getMessage());
		return "login";
	}
		catch(Exception e) {
		
		model.addAttribute("errorMessage","Unable to connect to genesys:"+e.getMessage()+" Organization or Selected Environment is incorrect "+environment);
		return "login";
	}
	
		
}
	
	@GetMapping("/upload")
	public String showUploadPage(@ModelAttribute("organizationName")String organizationName,
								@ModelAttribute("environment")String environment,Model model) {
		
		model.addAttribute("OrganizationName",organizationName);
		model.addAttribute("environment",environment);
		return "upload";
	}
		
	
	// Handle File Upload
	
	@PostMapping("/upload")
	public String handleFileUpload(@RequestParam("file")MultipartFile file,
			HttpSession httpSession,
			RedirectAttributes redirectAttributes,Model model){
		
		

		try {
			
			String organizationName= (String) httpSession.getAttribute("organizationName");
			String environment = (String)httpSession.getAttribute("environment");
			
			if(organizationName==null || environment==null) {
				model.addAttribute("errorMessage","Session expired. Please login in again.");
				return "login";
			}
			
		@SuppressWarnings("unchecked")
		Map<String, String> credentials = (Map<String,String>) httpSession.getAttribute("credentials");
		if(credentials ==null || !orgConfigService.validateCredentials(credentials,environment)) {
			throw new IllegalArgumentException("Client credentials have changed or are invalid. Please log in again:");
		}
			
//		String organizationName= (String) httpSession.getAttribute("organizationName");
//		String environment = (String)httpSession.getAttribute("environment");
//		
//		if(organizationName==null || environment==null) {
//			model.addAttribute("errorMessage","Session expired. Please login in again.");
//			return "login";
//		}
		
		//process the CSV file and create Skill
		List<String> results = genesysService.createSkillFromCsv(file, organizationName,environment);
		//add the results to the redirect attributes so it can be displayed in the success message
		model.addAttribute("results",results);
		model.addAttribute("successMessage","Skills upload successfully");
		
		redirectAttributes.addFlashAttribute("results",results);
		return "redirect:/skills/upload";
		}
		catch(IllegalArgumentException e) {
			model.addAttribute("errorMessage"+ e.getLocalizedMessage());
			return "login";
		}
	catch(IOException e) {
		model.addAttribute("errorMessage"+e.getMessage());
		return "upload";
	}catch(Exception e) {
		model.addAttribute("errorMessage","Error processing the files:"+e.getMessage());
		return "upload";
	}
	}
		
	// show results after processing the file
	@GetMapping("/results")
	public String showResults(Model model) {
		return "results";
	}
	
	


	
	
}
